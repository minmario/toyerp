package com.example.toyerp.domain.account.dto.response;

import lombok.Data;

@Data
public class AccountSubjectResponse {
    private int code;
    private String name;
    private String type;
    private String description;
}
package com.example.toyerp.domain.account.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import com.example.toyerp.domain.account.vo.AccountSubjectVO;

public interface AccountSubjectMapper {
    List<AccountSubjectVO> getAllAccountSubjects();

    AccountSubjectVO getAccountSubjectByCode(@Param("code") int code); // code가 문자열이면 String으로

    int insertAccountSubject(AccountSubjectVO vo);

    int updateAccountSubject(AccountSubjectVO vo);

    int deleteAccountSubject(@Param("code") int code);
}
package com.example.toyerp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToyerpApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToyerpApplication.class, args);
	}

}

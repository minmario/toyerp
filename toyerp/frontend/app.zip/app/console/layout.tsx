"use client"

import { ReactNode, useMemo } from "react"
import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"

export default function ConsoleLayout({ children }: { children: ReactNode }) {
  // 실제로는 서버에서 읽거나 middleware/JWT로 처리
  const userRole = "admin"

  const menu = useMemo(
    () => [
      { href: "/dashboard", label: "대시보드", key: "dashboard" },
      { href: "/employees", label: "직원 관리", key: "employees", roles: ["admin", "hr"] },
      { href: "/user-approval", label: "회원 승인", key: "user-approval", roles: ["admin"] },
      { href: "/accounts", label: "계정과목", key: "accounts", roles: ["admin", "finance"] },
      { href: "/journal", label: "전표 입력", key: "journal", roles: ["admin", "finance"] },
      { href: "/inventory", label: "재고 관리", key: "inventory", roles: ["admin", "ops"] },
      { href: "/reports", label: "리포트", key: "reports", roles: ["admin", "finance", "ops"] },
    ],
    []
  )

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar userRole={userRole} menu={menu} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header userRole={userRole} />
        <main className="flex-1 overflow-y-auto p-8">{children}</main>
      </div>
    </div>
  )
}